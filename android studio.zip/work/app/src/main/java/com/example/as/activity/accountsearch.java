package com.example.as.activity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.as.R;
import com.example.as.dao.InaccountDAO;
import com.example.as.dao.OutaccountDAO;
import com.example.as.model.Tb_inaccount;
import com.example.as.model.Tb_outaccount;

import org.w3c.dom.Text;

public class accountsearch extends Activity {
    public static final String FLAG = "id";
    ListView ininfo, outinfo;
    Button searchButton;
    public static int searchMoney;
    String strType = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchaccountinfo);
        ininfo = (ListView) findViewById(R.id.lvinaccountinfo);
        outinfo = (ListView) findViewById(R.id.lvoutaccountinfo);

        ShowinInfo();
        ShowoutInfo();

        searchButton = (Button) findViewById(R.id.button);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText searchText = (EditText) findViewById((R.id.searchEditText));
                if (!searchText.getText().toString().isEmpty()) {
                    searchMoney = Integer.parseInt(searchText.getText().toString());
                    Toast.makeText(accountsearch.this, String.valueOf(searchMoney), Toast.LENGTH_SHORT).show();
                    SearchinInfo();
                    SearchoutInfo();
                }else{
                    ShowinInfo();
                    ShowoutInfo();
                }
            }
        });
    }

    private void ShowinInfo() {
        String[] strInfos = null;
        ArrayAdapter<String> arrayAdapter = null;
        InaccountDAO inaccountinfo = new InaccountDAO(accountsearch.this);
        List<Tb_inaccount> listininfos = inaccountinfo.getScrollData(0,
                (int) inaccountinfo.getCount());

        Collections.sort(listininfos, new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
// 获取 o1 和 o2 的时间
                String time1 = "";
                String time2 = "";
                    time1 = ((Tb_inaccount) o1).getTime();
                    time2 = ((Tb_inaccount) o2).getTime();
                return time1.compareTo(time2);
            }
        });
        strInfos = new String[listininfos.size()];
        int i = 0;
        for (Object obj : listininfos) {
            if (obj instanceof Tb_inaccount) {
                Tb_inaccount tb_inaccount = (Tb_inaccount) obj;
                strInfos[i] = String.format("%1$-10s %2$-10s %3$-15s %4$15s", tb_inaccount.getid(),
                        tb_inaccount.getType(), tb_inaccount.getMoney(), tb_inaccount.getTime());
            }
            i++;
        }
        arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, strInfos);
        ininfo.setAdapter(arrayAdapter);

        ininfo.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String strInfo = String.valueOf(((TextView) view).getText());
                String strid = strInfo.substring(0, strInfo.indexOf(' '));
                Intent intent = new Intent(accountsearch.this, InfoManage.class);
                // 使用 putExtra 方法传递信息
                intent.putExtra("key1", strid);
                intent.putExtra("key2", "btnininfo");

                startActivity(intent);
            }
        });
    }

    private void ShowoutInfo() {
        String[] strInfos = null;
        ArrayAdapter<String> arrayAdapter = null;
        OutaccountDAO outaccountinfo = new OutaccountDAO(accountsearch.this);
        List<Tb_outaccount> listoutinfos = outaccountinfo.getScrollData(0,
                (int) outaccountinfo.getCount());


        Collections.sort(listoutinfos, new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
// 获取 o1 和 o2 的时间
                String time1 = "";
                String time2 = "";
                    time1 = ((Tb_outaccount) o1).getTime();
                    time2 = ((Tb_outaccount) o2).getTime();
                return time1.compareTo(time2);
            }
        });
        strInfos = new String[listoutinfos.size()];
        int i = 0;
        for (Object obj : listoutinfos) {
             if (obj instanceof Tb_outaccount) {
                Tb_outaccount tb_outaccount = (Tb_outaccount) obj;
                strInfos[i] = String.format("%1$-10s %2$-10s %3$-15s %4$15s", tb_outaccount.getid(),
                        tb_outaccount.getType(), tb_outaccount.getMoney(), tb_outaccount.getTime());
            }
            i++;
        }


        arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, strInfos);
        outinfo.setAdapter(arrayAdapter);

        outinfo.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String strInfo = String.valueOf(((TextView) view).getText());
                String strid = strInfo.substring(0, strInfo.indexOf(' '));
                Intent intent = new Intent(accountsearch.this, InfoManage.class);
                // 使用 putExtra 方法传递信息
                intent.putExtra("key1", strid);
                intent.putExtra("key2", "btnoutinfo");
                startActivity(intent);
            }
        });
    }


    private void SearchinInfo() {
        String[] strInfos = null;
        ArrayAdapter<String> arrayAdapter = null;
        InaccountDAO inaccountinfo = new InaccountDAO(accountsearch.this);
        List<Tb_inaccount> listininfos = inaccountinfo.getScrollData(0,
                (int) inaccountinfo.getCount());

        List<Object> searchResults = new ArrayList<Object>();

// 遍历 listinfos 列表，查找与 searchMoney 相匹配的数据
        for (Object obj : listininfos) {
                Tb_inaccount tb_inaccount = (Tb_inaccount) obj;
                if (tb_inaccount.getMoney() == searchMoney) {
                    searchResults.add(tb_inaccount);
                }
            }

// 将查询结果存储在 strInfos 数组中
        strInfos = new String[searchResults.size()];
        int i = 0;
        for (Object obj : searchResults) {
            if (obj instanceof Tb_inaccount) {
                Tb_inaccount tb_inaccount = (Tb_inaccount) obj;
        strInfos[i] = String.format("%1$-10s %2$-10s %3$-15s %4$15s", tb_inaccount.getid(),
                tb_inaccount.getType(), tb_inaccount.getMoney(), tb_inaccount.getTime());
    }
    i++;
}
        arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, strInfos);
        ininfo.setAdapter(arrayAdapter);
        }


    private void SearchoutInfo() {
        String[] strInfos = null;
        ArrayAdapter<String> arrayAdapter = null;

        OutaccountDAO outaccountinfo = new OutaccountDAO(accountsearch.this);
        List<Tb_outaccount> listoutinfos = outaccountinfo.getScrollData(0,
                (int) outaccountinfo.getCount());

        List<Object> searchResults = new ArrayList<Object>();

// 遍历 listinfos 列表，查找与 searchMoney 相匹配的数据
        for (Object obj : listoutinfos) {
        if (obj instanceof Tb_outaccount) {
                Tb_outaccount tb_outaccount = (Tb_outaccount) obj;
                if (tb_outaccount.getMoney() == searchMoney) {
                    searchResults.add(tb_outaccount);
                }
            }
        }

// 将查询结果存储在 strInfos 数组中
        strInfos = new String[searchResults.size()];
        int i = 0;
        for (Object obj : searchResults) {
             if (obj instanceof Tb_outaccount) {
                Tb_outaccount tb_outaccount = (Tb_outaccount) obj;
                strInfos[i] = String.format("%1$-10s %2$-10s %3$-15s %4$15s", tb_outaccount.getid(),
                        tb_outaccount.getType(), tb_outaccount.getMoney(), tb_outaccount.getTime());
            }
            i++;
        }
        arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, strInfos);
        outinfo.setAdapter(arrayAdapter);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        ShowinInfo();
        ShowoutInfo();
    }
}
