package com.example.as.activity;

import java.util.Calendar;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.as.R;
import com.example.as.dao.InaccountDAO;
import com.example.as.dao.OutaccountDAO;
import com.example.as.model.Tb_inaccount;
import com.example.as.model.Tb_outaccount;

public class accountinfo extends Activity {
    public static final String FLAG = "id";
    public double balance = 0;
    public double outTotal = 0;
    public double inTotal = 0;
    ListView lvinfo;
    String strType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inaccountinfo);
        TextView balanceView = findViewById(R.id.sum);
        TextView inView = findViewById(R.id.in);
        TextView outView = findViewById(R.id.out);
        sum();

        balanceView.setText(String.format("总余额：%.2f", balance));
        outView.setText(String.format("当月支出：%.2f", outTotal));
        inView.setText(String.format("当月收入：%.2f", inTotal));
    }

    private void sum() {
        OutaccountDAO outaccountinfo = new OutaccountDAO(accountinfo.this);
        List<Tb_outaccount> listoutinfos = outaccountinfo.getScrollData(0,
                (int) outaccountinfo.getCount());

        InaccountDAO inaccountinfo = new InaccountDAO(accountinfo.this);
        List<Tb_inaccount> listininfos = inaccountinfo.getScrollData(0,
                (int) inaccountinfo.getCount());


        for (Tb_outaccount tb_outaccount : listoutinfos) {
            balance -= tb_outaccount.getMoney();
        }

        for (Tb_inaccount tb_inaccount : listininfos) {
            balance += tb_inaccount.getMoney();
        }



        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1; // 月份是从0开始计算的，所以要加1

// 分别计算当前年月的支出总和和收入总和

        for (Tb_outaccount tb_outaccount : listoutinfos) {
            String time = tb_outaccount.getTime();
            int y = Integer.parseInt(time.substring(0, 4));
            int m = Integer.parseInt(time.substring(5, 7));
            if (y == year && m == month) {
                outTotal += tb_outaccount.getMoney();
            }
        }
        for (Tb_inaccount tb_inaccount : listininfos) {
            String time = tb_inaccount.getTime();
            int y = Integer.parseInt(time.substring(0, 4));
            int m = Integer.parseInt(time.substring(5, 7));
            if (y == year && m == month) {
                inTotal += tb_inaccount.getMoney();
            }
        }
    }

}
